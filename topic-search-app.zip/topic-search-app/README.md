# TOTLE Frontend Developer Intern -Round 2 Submission

# Problem Satement
Build a React component (`TopicSearch`) that displays a list of topics and allows filtering by a search input (case-insensitive). Displays a message if no matches are found.

# Live Features
- Real-time topic filtering
- Case-insensitive search
- Clean, responsive UI using CSS
- Error handling for no matches
- Easy to set up and run

# Folder Structure
topic-search-app/
├── public/
│ └── index.html
├── src/
│ ├── components/
│ │ └── TopicSearch.jsx
│ ├── App.jsx
│ ├── index.js
│ └── styles.css
├── package.json
└── README.md

# Setup Instructions
### 1. Clone the Repository

git clone https://github.com/Poonam-275/Coding_Round_TOTLE.git
cd topic-search-app

Or extract the ZIP file if downloaded manually

### 2. Install Dependencies
npm install

### 3. Start the App
npm start