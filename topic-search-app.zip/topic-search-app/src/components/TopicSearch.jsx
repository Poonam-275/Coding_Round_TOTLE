import React, { useState, useEffect } from "react";
import "../styles.css";

const topics = [
  { id: 1, name: "Thermodynamics", category: "Physics" },
  { id: 2, name: "Quantum Mechanics", category: "Physics" },
  { id: 3, name: "Machine Learning", category: "Computer Science" },
  { id: 4, name: "Photosynthesis", category: "Biology" },
  { id: 5, name: "Abstract Algebra", category: "Mathematics" },
];

const TopicSearch = () => {
  const [query, setQuery] = useState("");
  const [filteredTopics, setFilteredTopics] = useState(topics);

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      const results = topics.filter((topic) =>
        topic.name.toLowerCase().includes(query.toLowerCase())
      );
      setFilteredTopics(results);
    }, 300);
    return () => clearTimeout(delayDebounce);
  }, [query]);

  return (
    <div className="topic-container">
      <h1>Explore Topics</h1>
      <input
        className="search-box"
        type="text"
        placeholder="Type to search topics..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <div className="cards-wrapper">
        {filteredTopics.length > 0 ? (
          filteredTopics.map((topic) => (
            <div key={topic.id} className="topic-card">
              <h2>{topic.name}</h2>
              <span className="category-tag">{topic.category}</span>
            </div>
          ))
        ) : (
          <p className="not-found">
            {query.trim() === ""
              ? "Start typing to explore topics."
              : "No topics found."}
          </p>
        )}
      </div>
    </div>
  );
};

export default TopicSearch;
